import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { NotificationItem, Post, Reply, User } from "@/types";
import { anonName } from "@/lib/avatar";

type State = {
  currentUser: User | null;
  posts: Post[];
  replies: Reply[];
  notifications: NotificationItem[];
};

type Ctx = State & {
  signIn: (realName: string) => void;
  signUp: (input: { realName: string; anonymousName: string; location: string; interest: string }) => void;
  signOut: () => void;
  createPost: (input: { title: string; content: string; category: string; tags: string[]; anonymous: boolean }) => Post;
  addReply: (postId: string, content: string) => void;
  toggleUpvote: (postId: string) => void;
  acceptReply: (postId: string, replyId: string) => void;
  checkIn: () => { awarded: number; streak: number } | null;
  markAllRead: () => void;
  pushNotification: (n: Omit<NotificationItem, "id" | "createdAt" | "isRead">) => void;
  addNotification: (n: Omit<NotificationItem, "id" | "createdAt" | "isRead">) => void;
  blockUser: (userId: string) => void;
};

const AppContext = createContext<Ctx | null>(null);
const KEY = "problemapp:v1";

function seedPosts(): Post[] {
  return [
    {
      id: "seed-1",
      authorId: "seed-user",
      authorName: "CuriousFox204",
      authorAvatarSeed: "seed-user",
      anonymous: true,
      category: "Study",
      title: "How do you stay focused for 4+ hours?",
      content: "I lose focus after 45 minutes. Any techniques that actually work long-term?",
      tags: ["focus", "productivity"],
      upvotes: 12,
      upvotedBy: [],
      hasAcceptedSolution: false,
      createdAt: new Date(Date.now() - 3600_000).toISOString(),
    },
    {
      id: "seed-2",
      authorId: "seed-user-2",
      authorName: "Rahim",
      authorAvatarSeed: "seed-user-2",
      anonymous: false,
      category: "Career",
      title: "First job offer — negotiate or accept?",
      content: "Got my first offer as a junior dev. Should I try to negotiate salary?",
      tags: ["career", "salary"],
      upvotes: 5,
      upvotedBy: [],
      hasAcceptedSolution: false,
      createdAt: new Date(Date.now() - 7200_000).toISOString(),
    },
  ];
}

function load(): State {
  if (typeof window === "undefined") return { currentUser: null, posts: [], replies: [], notifications: [] };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return { currentUser: null, posts: seedPosts(), replies: [], notifications: [] };
}

function save(s: State) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch {}
}

function rid() { return Math.random().toString(36).slice(2, 10); }

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(() => ({ currentUser: null, posts: [], replies: [], notifications: [] }));
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => { setState(load()); setHydrated(true); }, []);
  useEffect(() => { if (hydrated) save(state); }, [state, hydrated]);

  const value = useMemo<Ctx>(() => ({
    ...state,
    signIn: (realName) => {
      const id = rid();
      const user: User = {
        id,
        realName: realName.trim() || "User",
        anonymousName: anonName(),
        avatarSeed: id,
        isPremium: false,
        points: 0,
        streak: 0,
        isStudentVerified: false,
      };
      setState((s) => ({ ...s, currentUser: user }));
    },
    signUp: ({ realName, anonymousName, location, interest }) => {
      const id = rid();
      const user: User = {
        id,
        realName: realName.trim() || "User",
        anonymousName: anonymousName.trim() || anonName(),
        avatarSeed: id,
        isPremium: false,
        points: 0,
        streak: 0,
        isStudentVerified: false,
        location,
        interest,
      };
      setState((s) => ({
        ...s,
        currentUser: user,
        notifications: [
          { id: rid(), title: "Welcome to Problem App 👋", message: "Thanks for joining! Explore the feed to get started.", createdAt: new Date().toISOString(), type: "system", isRead: false },
          ...s.notifications,
        ],
      }));
    },
    signOut: () => setState((s) => ({ ...s, currentUser: null })),
    createPost: (input) => {
      const u = state.currentUser;
      if (!u) throw new Error("Not signed in");
      const post: Post = {
        id: rid(),
        authorId: u.id,
        authorName: input.anonymous ? u.anonymousName : u.realName,
        authorAvatarSeed: input.anonymous ? u.anonymousName : u.avatarSeed,
        anonymous: input.anonymous,
        category: input.category,
        title: input.title,
        content: input.content,
        tags: input.tags,
        upvotes: 0,
        upvotedBy: [],
        hasAcceptedSolution: false,
        createdAt: new Date().toISOString(),
      };
      setState((s) => ({
        ...s,
        posts: [post, ...s.posts],
        currentUser: s.currentUser ? { ...s.currentUser, points: s.currentUser.points + 5 } : s.currentUser,
      }));
      return post;
    },
    addReply: (postId, content) => {
      const u = state.currentUser;
      if (!u) return;
      const reply: Reply = {
        id: rid(),
        postId,
        authorId: u.id,
        authorName: u.anonymousName,
        authorAvatarSeed: u.anonymousName,
        content,
        isAccepted: false,
        createdAt: new Date().toISOString(),
      };
      setState((s) => ({
        ...s,
        replies: [...s.replies, reply],
        currentUser: s.currentUser ? { ...s.currentUser, points: s.currentUser.points + 2 } : s.currentUser,
        notifications: [
          { id: rid(), title: "New reply", message: `${reply.authorName} replied to a post`, createdAt: new Date().toISOString(), type: "reply", isRead: false, postId },
          ...s.notifications,
        ],
      }));
    },
    toggleUpvote: (postId) => {
      const u = state.currentUser;
      if (!u) return;
      setState((s) => ({
        ...s,
        posts: s.posts.map((p) => {
          if (p.id !== postId) return p;
          const has = p.upvotedBy.includes(u.id);
          return {
            ...p,
            upvotedBy: has ? p.upvotedBy.filter((x) => x !== u.id) : [...p.upvotedBy, u.id],
            upvotes: has ? p.upvotes - 1 : p.upvotes + 1,
          };
        }),
      }));
    },
    acceptReply: (postId, replyId) => {
      setState((s) => ({
        ...s,
        posts: s.posts.map((p) => (p.id === postId ? { ...p, hasAcceptedSolution: true } : p)),
        replies: s.replies.map((r) => (r.postId === postId ? { ...r, isAccepted: r.id === replyId } : r)),
      }));
    },
    checkIn: () => {
      const u = state.currentUser;
      if (!u) return null;
      const today = new Date().toISOString().slice(0, 10);
      if (u.lastCheckInDate === today) return null;
      const yesterday = new Date(Date.now() - 86400_000).toISOString().slice(0, 10);
      const nextStreak = u.lastCheckInDate === yesterday ? u.streak + 1 : 1;
      const awarded = 10 + Math.min(nextStreak, 7) * 2;
      setState((s) => ({
        ...s,
        currentUser: s.currentUser
          ? { ...s.currentUser, streak: nextStreak, lastCheckInDate: today, points: s.currentUser.points + awarded }
          : s.currentUser,
        notifications: [
          { id: rid(), title: `+${awarded} points`, message: `Day ${nextStreak} streak!`, createdAt: new Date().toISOString(), type: "streak", isRead: false },
          ...s.notifications,
        ],
      }));
      return { awarded, streak: nextStreak };
    },
    markAllRead: () => setState((s) => ({ ...s, notifications: s.notifications.map((n) => ({ ...n, isRead: true })) })),
    pushNotification: (n) => setState((s) => ({
      ...s,
      notifications: [{ ...n, id: rid(), createdAt: new Date().toISOString(), isRead: false }, ...s.notifications],
    })),
    addNotification: (n) => setState((s) => ({
      ...s,
      notifications: [{ ...n, id: rid(), createdAt: new Date().toISOString(), isRead: false }, ...s.notifications],
    })),
    blockUser: (userId) => setState((s) => ({
      ...s,
      currentUser: s.currentUser
        ? { ...s.currentUser, blockedUsers: Array.from(new Set([...(s.currentUser.blockedUsers ?? []), userId])) }
        : s.currentUser,
      notifications: [
        { id: rid(), title: "User blocked", message: "You will no longer see posts from this user.", createdAt: new Date().toISOString(), type: "system", isRead: false },
        ...s.notifications,
      ],
    })),
  }), [state]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useStore() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useStore must be used within StoreProvider");
  return ctx;
}