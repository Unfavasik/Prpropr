export type Tab = "home" | "adda" | "create" | "rewards" | "profile";

export type User = {
  id: string;
  realName: string;
  anonymousName: string;
  avatarSeed: string;
  isPremium: boolean;
  points: number;
  streak: number;
  lastCheckInDate?: string;
  isStudentVerified: boolean;
  location?: string;
  interest?: string;
  blockedUsers?: string[];
};

export type Post = {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatarSeed: string;
  anonymous: boolean;
  category: string;
  title: string;
  content: string;
  tags: string[];
  upvotes: number;
  upvotedBy: string[];
  hasAcceptedSolution: boolean;
  createdAt: string;
};

export type Reply = {
  id: string;
  postId: string;
  authorId: string;
  authorName: string;
  authorAvatarSeed: string;
  content: string;
  isAccepted: boolean;
  createdAt: string;
};

export type NotificationItem = {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  type: "reply" | "like" | "system" | "streak";
  isRead: boolean;
  postId?: string;
};

export const CATEGORIES = [
  "Study",
  "Career",
  "Health",
  "Relationships",
  "Tech",
  "Money",
  "Other",
] as const;