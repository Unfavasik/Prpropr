// Simple deterministic gradient avatar (no external dep).
export function avatarGradient(seed: string): string {
  let h = 0;
  for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) >>> 0;
  const a = h % 360;
  const b = (a + 60 + (h % 120)) % 360;
  return `linear-gradient(135deg, hsl(${a} 70% 55%), hsl(${b} 70% 45%))`;
}

export function anonName(): string {
  const adjs = ["Silent", "Curious", "Brave", "Kind", "Witty", "Calm", "Bold", "Lucky"];
  const nouns = ["Panda", "Falcon", "Otter", "Fox", "Koala", "Wolf", "Tiger", "Hawk"];
  const a = adjs[Math.floor(Math.random() * adjs.length)];
  const n = nouns[Math.floor(Math.random() * nouns.length)];
  return `${a}${n}${Math.floor(Math.random() * 900 + 100)}`;
}