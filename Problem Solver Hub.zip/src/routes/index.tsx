import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { formatDistanceToNow } from "date-fns";
import {
  Heart,
  MessageCircle,
  Check,
  X,
  Bookmark,
  MoreHorizontal,
  CheckCircle2,
  Send,
  ChevronUp,
  Search,
  Flag,
  Ban,
  Plus,
  Ghost,
  Sparkles,
  Star,
  Flame,
} from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { UserAvatar } from "@/components/UserAvatar";
import { useStore } from "@/context/AppContext";
import type { Post } from "@/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Home — ProblemApp" },
      { name: "description", content: "Browse and solve problems shared by the ProblemApp community." },
      { property: "og:title", content: "Home — ProblemApp" },
      { property: "og:description", content: "Browse and solve problems shared by the ProblemApp community." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: RouteComp,
});

function RouteComp() {
  const { currentUser, posts, replies } = useStore();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);

  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [activeTab, setActiveTab] = useState<"For You" | "Trending" | "Recent">("For You");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const t = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(t);
  }, []);

  const categories = useMemo(
    () => Array.from(new Set(posts.map((p) => p.category))).filter(Boolean),
    [posts],
  );

  const blockedIds = currentUser?.blockedUsers ?? [];

  const filteredPosts = useMemo(() => {
    const q = searchQuery.toLowerCase();
    let list = posts.filter((post) => {
      if (blockedIds.includes(post.authorId)) return false;
      const matchesSearch =
        !q ||
        post.title.toLowerCase().includes(q) ||
        post.content.toLowerCase().includes(q);
      const matchesCategory = selectedCategory ? post.category === selectedCategory : true;
      return matchesSearch && matchesCategory;
    });
    if (activeTab === "Trending") {
      list = [...list].sort((a, b) => b.upvotes - a.upvotes);
    } else if (activeTab === "Recent") {
      list = [...list].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
      );
    }
    return list;
  }, [posts, blockedIds, searchQuery, selectedCategory, activeTab]);

  if (hydrated && !currentUser) return <Navigate to="/auth" />;

  return (
    <>
      <AppHeader title="Home" />
      <main className="flex flex-1 flex-col overflow-y-auto">
        {/* Tabs */}
        <div className="flex shrink-0 items-center gap-4 border-b border-border px-5 py-3 text-sm font-medium">
          {(["For You", "Trending", "Recent"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "relative py-1",
                activeTab === tab ? "text-foreground" : "text-muted-foreground",
              )}
            >
              {tab}
              {activeTab === tab && (
                <motion.div
                  layoutId="hometab"
                  className="absolute -bottom-[13px] left-0 right-0 h-0.5 rounded-full bg-primary"
                />
              )}
            </button>
          ))}
        </div>

        <div className="flex flex-col space-y-6 p-4">
          <StreakWidget />

          {/* Search + Categories */}
          <div className="flex flex-col gap-3">
            <div className="flex h-11 items-center rounded-xl border border-border bg-card px-3">
              <Search size={18} className="shrink-0 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search problems by keywords..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 border-none bg-transparent px-2 text-[13px] outline-none placeholder:text-muted-foreground/70"
              />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
              <CategoryChip
                active={selectedCategory === null}
                onClick={() => setSelectedCategory(null)}
                label="All Categories"
              />
              {categories.map((c) => (
                <CategoryChip
                  key={c}
                  active={selectedCategory === c}
                  onClick={() => setSelectedCategory(c)}
                  label={c}
                />
              ))}
            </div>
          </div>

          {isLoading ? (
            <FeedSkeleton />
          ) : filteredPosts.length > 0 ? (
            <div className="flex flex-col gap-4">
              {filteredPosts.map((post) => (
                <FeedPostCard
                  key={post.id}
                  post={post}
                  replyCount={replies.filter((r) => r.postId === post.id).length}
                  onOpen={() => setSelectedPost(post)}
                />
              ))}
            </div>
          ) : (
            <EmptyState activeTab={activeTab} />
          )}
        </div>
      </main>

      <AnimatePresence>
        {selectedPost && (
          <BottomSheet post={selectedPost} onClose={() => setSelectedPost(null)} />
        )}
      </AnimatePresence>

      <BottomNav />
    </>
  );
}

function CategoryChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "whitespace-nowrap rounded-full border px-4 py-1.5 text-[12px] font-medium transition-colors",
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-card text-muted-foreground hover:text-foreground",
      )}
    >
      {label}
    </button>
  );
}

function StreakWidget() {
  const { currentUser, checkIn } = useStore();
  const today = new Date().toISOString().slice(0, 10);
  const checkedIn = currentUser?.lastCheckInDate === today;
  return (
    <div className="relative overflow-hidden rounded-[20px] border border-border bg-gradient-to-br from-primary/20 via-card to-card p-5">
      <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-primary/20 blur-2xl" />
      <div className="relative flex items-center gap-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/20 text-primary">
          <Flame size={22} />
        </div>
        <div className="flex-1">
          <div className="text-sm font-semibold">Daily check-in</div>
          <div className="text-xs text-muted-foreground">
            Streak: {currentUser?.streak ?? 0} day{(currentUser?.streak ?? 0) === 1 ? "" : "s"} · {currentUser?.points ?? 0} pts
          </div>
        </div>
        <button
          onClick={() => checkIn()}
          disabled={checkedIn}
          className={cn(
            "rounded-full px-4 py-2 text-xs font-semibold transition-colors",
            checkedIn
              ? "bg-secondary text-muted-foreground"
              : "bg-primary text-primary-foreground hover:opacity-90",
          )}
        >
          {checkedIn ? "Claimed" : "Claim"}
        </button>
      </div>
    </div>
  );
}

function FeedSkeleton() {
  return (
    <div className="flex flex-col gap-4">
      {[1, 2, 3].map((i) => (
        <div key={i} className="rounded-[24px] border border-border/50 bg-card p-5">
          <div className="mb-4 flex items-center gap-3">
            <div className="h-10 w-10 animate-pulse rounded-full bg-muted" />
            <div className="flex-1 space-y-2">
              <div className="h-3 w-24 animate-pulse rounded bg-muted" />
              <div className="h-3 w-16 animate-pulse rounded bg-muted" />
            </div>
          </div>
          <div className="space-y-2">
            <div className="h-5 w-full animate-pulse rounded bg-muted" />
            <div className="h-4 w-3/4 animate-pulse rounded bg-muted" />
          </div>
        </div>
      ))}
    </div>
  );
}

function FeedPostCard({
  post,
  replyCount,
  onOpen,
}: {
  post: Post;
  replyCount: number;
  onOpen: () => void;
}) {
  const { currentUser, toggleUpvote, blockUser, addNotification } = useStore();
  const [showOptions, setShowOptions] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const isUpvoted = !!currentUser && post.upvotedBy.includes(currentUser.id);

  return (
    <motion.div
      layoutId={`post-${post.id}`}
      onClick={onOpen}
      className="relative cursor-pointer rounded-[24px] border border-border/50 bg-card p-5"
    >
      <div className="mb-4 flex items-center gap-3">
        <UserAvatar seed={post.authorAvatarSeed} name={post.authorName} size={40} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-[15px] font-medium">
            <span className="truncate">{post.authorName}</span>
            {post.anonymous && (
              <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">anon</span>
            )}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span>{formatDistanceToNow(new Date(post.createdAt))} ago</span>
            <span>•</span>
            <span>{post.category}</span>
          </div>
        </div>
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowOptions((v) => !v);
            }}
            className="text-muted-foreground hover:text-foreground"
          >
            <MoreHorizontal size={20} />
          </button>
          <AnimatePresence>
            {showOptions && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: -5 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -5 }}
                className="absolute right-0 top-full z-30 mt-2 flex w-36 flex-col gap-1 overflow-hidden rounded-xl border border-border bg-card p-1.5 shadow-lg"
              >
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    addNotification({ title: "Post reported", message: "Thanks for keeping the community safe.", type: "system" });
                    setShowOptions(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-muted-foreground transition-colors hover:bg-white/5 hover:text-foreground"
                >
                  <Flag size={14} className="text-orange-400" />
                  Report
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    blockUser(post.authorId);
                    setShowOptions(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-destructive transition-colors hover:bg-destructive/10"
                >
                  <Ban size={14} />
                  Block user
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      <h2 className="mb-2 text-[17px] font-semibold leading-snug">{post.title}</h2>
      <p className="mb-4 line-clamp-3 text-sm leading-relaxed text-muted-foreground">{post.content}</p>

      {post.hasAcceptedSolution && (
        <div className="mb-4 flex w-fit items-center gap-1.5 rounded-lg border border-[color:var(--success)]/20 bg-[color:var(--success)]/10 px-3 py-1.5 text-xs font-semibold text-[color:var(--success)]">
          <CheckCircle2 size={14} /> Solution accepted
        </div>
      )}

      <div className="mt-2 flex items-center justify-between border-t border-border/50 pt-4 text-muted-foreground">
        <div className="flex items-center gap-6">
          <button
            onClick={(e) => {
              e.stopPropagation();
              toggleUpvote(post.id);
            }}
            className={cn(
              "flex items-center gap-1.5 transition-colors",
              isUpvoted ? "text-pink-500" : "hover:text-foreground",
            )}
          >
            <Heart size={18} className={isUpvoted ? "fill-pink-500" : ""} />
            <span className="text-sm font-medium">{post.upvotes}</span>
          </button>
          <div className="flex items-center gap-1.5">
            <MessageCircle size={18} />
            <span className="text-sm font-medium">{replyCount} Answers</span>
          </div>
        </div>
        <button
          onClick={(e) => {
            e.stopPropagation();
            setIsSaved((v) => !v);
            if (!isSaved) {
              addNotification({ title: "Saved", message: "Post saved to your bookmarks.", type: "system" });
            }
          }}
          className={cn("transition-colors", isSaved ? "text-primary" : "hover:text-foreground")}
        >
          <Bookmark size={18} className={isSaved ? "fill-primary" : ""} />
        </button>
      </div>
    </motion.div>
  );
}

function EmptyState({ activeTab }: { activeTab: string }) {
  const navigate = useNavigate();
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative mt-4 flex flex-col items-center justify-center overflow-hidden rounded-[32px] border border-dashed border-white/5 bg-gradient-to-b from-card/30 to-transparent px-6 py-16 text-center"
    >
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[200px] w-[200px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary/10 blur-[50px]" />
      <div className="relative mb-8 flex h-32 w-32 items-center justify-center">
        <motion.div
          animate={{ y: [0, -10, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          className="relative z-10 flex h-24 w-24 items-center justify-center rounded-3xl border border-primary/30 bg-gradient-to-br from-primary/20 to-primary/5 backdrop-blur-md"
        >
          <Ghost size={44} className="text-primary" strokeWidth={1.5} />
        </motion.div>
        <motion.div
          animate={{ y: [0, 8, 0], rotate: [0, 10, 0] }}
          transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          className="absolute -left-2 top-2 z-20"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-full border border-pink-500/30 bg-pink-500/20">
            <MessageCircle size={18} className="text-pink-400" />
          </div>
        </motion.div>
        <motion.div
          animate={{ y: [0, -8, 0], rotate: [0, -15, 0] }}
          transition={{ duration: 3.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
          className="absolute -right-2 bottom-2 z-20"
        >
          <div className="flex h-12 w-12 items-center justify-center rounded-full border border-amber-500/30 bg-amber-500/20">
            <Star size={20} className="text-amber-400" />
          </div>
        </motion.div>
        <motion.div
          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="absolute right-4 top-0 z-0"
        >
          <Sparkles size={16} className="text-primary" />
        </motion.div>
      </div>
      <h3 className="mb-3 text-[22px] font-bold">It's quiet in here...</h3>
      <p className="mx-auto mb-8 max-w-[280px] text-[15px] leading-relaxed text-muted-foreground">
        {activeTab === "For You"
          ? "Looks like there's nothing new for you right now."
          : "We couldn't find any active problems matching your criteria."}
      </p>
      <motion.button
        whileTap={{ scale: 0.95 }}
        whileHover={{ scale: 1.05 }}
        onClick={() => navigate({ to: "/create" })}
        className="flex items-center gap-2 rounded-full bg-primary px-8 py-3.5 text-[15px] font-bold text-primary-foreground shadow-[0_0_30px_hsl(var(--primary)/0.4)]"
      >
        <Plus size={20} />
        <span>Create new problem</span>
      </motion.button>
    </motion.div>
  );
}

function BottomSheet({ post, onClose }: { post: Post; onClose: () => void }) {
  const { replies, acceptReply, currentUser, addReply } = useStore();
  const [newReply, setNewReply] = useState("");

  if (!currentUser) return null;

  const postReplies = replies.filter((r) => r.postId === post.id);
  const isOwner = currentUser.id === post.authorId;

  const handleAddReply = () => {
    if (!newReply.trim()) return;
    addReply(post.id, newReply.trim());
    setNewReply("");
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="fixed inset-0 z-30 bg-black/60 backdrop-blur-sm"
      />
      <motion.div
        layoutId={`post-${post.id}`}
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", bounce: 0, duration: 0.4 }}
        className="fixed inset-x-0 bottom-0 z-40 mx-auto flex h-[88vh] max-w-[500px] flex-col rounded-t-[32px] border-t border-border bg-background shadow-2xl"
      >
        <div className="flex justify-center p-3">
          <div className="h-1.5 w-12 rounded-full bg-border" />
        </div>

        <div className="flex shrink-0 items-center justify-between px-5 pb-3">
          <h2 className="text-lg font-semibold">Problem details</h2>
          <button
            onClick={onClose}
            className="rounded-full p-2 text-muted-foreground hover:text-foreground"
          >
            <X size={20} />
          </button>
        </div>

        <div className="flex-1 space-y-6 overflow-y-auto p-5 pt-0 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
          <div className="mb-6">
            <h3 className="mb-3 text-xl font-bold leading-snug">{post.title}</h3>
            <p className="text-[15px] leading-relaxed text-muted-foreground">{post.content}</p>
          </div>

          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Solutions ({postReplies.length})</h3>
          </div>

          <div className="space-y-4">
            {postReplies.map((reply) => (
              <div
                key={reply.id}
                className={cn(
                  "rounded-[20px] border p-4 transition-colors",
                  reply.isAccepted
                    ? "border-[color:var(--success)] bg-[color:var(--success)]/5"
                    : "border-border bg-card",
                )}
              >
                <div className="mb-3 flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <UserAvatar seed={reply.authorAvatarSeed} name={reply.authorName} size={32} />
                    <div>
                      <div className="text-[14px] font-medium">{reply.authorName}</div>
                      <div className="text-[11px] text-muted-foreground">
                        {formatDistanceToNow(new Date(reply.createdAt))} ago
                      </div>
                    </div>
                  </div>
                </div>
                <p className="pl-11 text-[15px] leading-relaxed text-foreground/90">{reply.content}</p>
                <div className="mt-3 flex items-center justify-between pl-11">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <button className="transition-colors hover:text-amber-500">
                      <ChevronUp size={16} />
                    </button>
                    <span className="text-xs font-medium">0</span>
                  </div>
                  {reply.isAccepted ? (
                    <div className="flex items-center gap-1.5 rounded-full border border-[color:var(--success)]/20 bg-[color:var(--success)]/10 px-3 py-1.5 text-xs font-bold text-[color:var(--success)]">
                      <Check size={14} strokeWidth={3} /> Accepted
                    </div>
                  ) : (
                    isOwner && !post.hasAcceptedSolution && (
                      <button
                        onClick={() => acceptReply(post.id, reply.id)}
                        className="flex items-center gap-1.5 rounded-full border border-[color:var(--success)] px-3 py-1.5 text-xs font-bold text-[color:var(--success)] transition-all hover:bg-[color:var(--success)] hover:text-background"
                      >
                        <Check size={14} strokeWidth={3} /> Accept
                      </button>
                    )
                  )}
                </div>
              </div>
            ))}
            {postReplies.length === 0 && (
              <div className="rounded-[24px] border border-dashed border-border bg-card py-10 text-center text-sm text-muted-foreground">
                No solutions yet. Be the first to help!
              </div>
            )}
          </div>
        </div>

        <div className="shrink-0 border-t border-border bg-background p-4 pb-8">
          <div className="flex items-center gap-2 rounded-full border border-border bg-input p-1 pl-4 pr-1">
            <input
              type="text"
              value={newReply}
              onChange={(e) => setNewReply(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddReply()}
              placeholder="Write your solution..."
              className="flex-1 bg-transparent text-[15px] outline-none placeholder:text-muted-foreground"
            />
            <button
              onClick={handleAddReply}
              disabled={!newReply.trim()}
              className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground transition-colors hover:opacity-90 disabled:bg-border disabled:opacity-50"
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      </motion.div>
    </>
  );
}