import { createFileRoute } from "@tanstack/react-router";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";

export const Route = createFileRoute("/adda")({
  head: () => ({ meta: [{ title: "Adda — ProblemApp" }, { name: "description", content: "Casual community chatroom." }] }),
  component: AddaPage,
});

function AddaPage() {
  return (
    <>
      <AppHeader title="Adda" />
      <main className="flex-1 overflow-y-auto px-4 py-6">
        <div className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          Adda chatroom coming soon — the casual community feed.
        </div>
      </main>
      <BottomNav />
    </>
  );
}