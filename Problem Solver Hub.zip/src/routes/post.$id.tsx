import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowBigUp, ArrowLeft, Check, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { BottomNav } from "@/components/BottomNav";
import { UserAvatar } from "@/components/UserAvatar";
import { useStore } from "@/context/AppContext";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/post/$id")({
  head: () => ({ meta: [{ title: "Problem — ProblemApp" }, { name: "description", content: "View a problem and its solutions." }, { name: "robots", content: "noindex" }] }),
  component: PostDetail,
});

function PostDetail() {
  const { id } = Route.useParams();
  const { posts, replies, currentUser, addReply, toggleUpvote, acceptReply } = useStore();
  const navigate = useNavigate();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  const [text, setText] = useState("");

  const post = posts.find((p) => p.id === id);
  if (hydrated && !currentUser) return <Navigate to="/auth" />;
  if (hydrated && !post) return <Navigate to="/" />;
  if (!post) return null;

  const postReplies = replies.filter((r) => r.postId === post.id);
  const isAuthor = currentUser?.id === post.authorId;
  const upvoted = currentUser ? post.upvotedBy.includes(currentUser.id) : false;

  return (
    <>
      <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-border bg-background/80 px-3 py-3 backdrop-blur">
        <button onClick={() => navigate({ to: "/" })} className="rounded-full p-2 hover:bg-secondary">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="min-w-0 flex-1 truncate text-sm text-muted-foreground">{post.category}</div>
      </header>
      <main className="flex-1 overflow-y-auto px-4 py-4">
        <article className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center gap-2.5">
            <UserAvatar seed={post.authorAvatarSeed} name={post.authorName} size={36} />
            <div className="min-w-0">
              <div className="text-sm font-medium">{post.authorName}</div>
              <div className="text-xs text-muted-foreground">{post.category}</div>
            </div>
            {post.hasAcceptedSolution && (
              <span className="ml-auto flex items-center gap-1 rounded-full bg-[color:var(--success)]/15 px-2 py-0.5 text-xs text-[color:var(--success)]">
                <CheckCircle2 className="h-3.5 w-3.5" /> solved
              </span>
            )}
          </div>
          <h1 className="mt-3 text-lg font-semibold">{post.title}</h1>
          <p className="mt-1 whitespace-pre-wrap text-sm text-muted-foreground">{post.content}</p>
          <button
            onClick={() => toggleUpvote(post.id)}
            className={cn(
              "mt-3 flex items-center gap-1 rounded-full px-3 py-1 text-sm text-muted-foreground",
              upvoted && "bg-primary/15 text-primary",
            )}
          >
            <ArrowBigUp className="h-4 w-4" /> {post.upvotes} upvotes
          </button>
        </article>

        <h2 className="mt-6 mb-2 text-sm font-semibold text-muted-foreground">
          Replies ({postReplies.length})
        </h2>
        <div className="space-y-2">
          {postReplies.length === 0 && (
            <div className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
              No replies yet — be the first to help.
            </div>
          )}
          {postReplies.map((r) => (
            <div
              key={r.id}
              className={cn(
                "rounded-2xl border border-border bg-card p-3",
                r.isAccepted && "border-[color:var(--success)]/60 bg-[color:var(--success)]/5",
              )}
            >
              <div className="flex items-center gap-2">
                <UserAvatar seed={r.authorAvatarSeed} name={r.authorName} size={28} />
                <div className="text-xs">
                  <div className="font-medium">{r.authorName}</div>
                </div>
                {r.isAccepted && (
                  <span className="ml-auto flex items-center gap-1 text-xs text-[color:var(--success)]">
                    <Check className="h-3.5 w-3.5" /> Accepted
                  </span>
                )}
              </div>
              <p className="mt-2 whitespace-pre-wrap text-sm">{r.content}</p>
              {isAuthor && !post.hasAcceptedSolution && (
                <button
                  onClick={() => {
                    acceptReply(post.id, r.id);
                    toast.success("Reply accepted");
                  }}
                  className="mt-2 rounded-full bg-[color:var(--success)]/20 px-3 py-1 text-xs text-[color:var(--success)]"
                >
                  Accept as solution
                </button>
              )}
            </div>
          ))}
        </div>
      </main>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (text.trim().length < 2) return;
          addReply(post.id, text.trim());
          setText("");
          toast.success("Reply posted (+2 points)");
        }}
        className="flex items-center gap-2 border-t border-border bg-background p-3"
      >
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Write a helpful reply..."
          className="flex-1 rounded-full border border-border bg-card px-4 py-2 text-sm outline-none focus:border-primary"
        />
        <button type="submit" className="rounded-full bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground">
          Send
        </button>
      </form>
      <BottomNav />
    </>
  );
}