import { createFileRoute, Link, Navigate, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, Bell } from "lucide-react";
import { useStore } from "@/context/AppContext";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/notifications")({
  head: () => ({ meta: [{ title: "Notifications — ProblemApp" }, { name: "description", content: "Your recent activity." }, { name: "robots", content: "noindex" }] }),
  component: NotifPage,
});

function NotifPage() {
  const { currentUser, notifications, markAllRead } = useStore();
  const navigate = useNavigate();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  useEffect(() => { markAllRead(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  if (hydrated && !currentUser) return <Navigate to="/auth" />;

  return (
    <>
      <header className="sticky top-0 z-20 flex items-center gap-2 border-b border-border bg-background/80 px-3 py-3 backdrop-blur">
        <button onClick={() => navigate({ to: "/" })} className="rounded-full p-2 hover:bg-secondary">
          <ArrowLeft className="h-5 w-5" />
        </button>
        <h1 className="text-base font-semibold">Notifications</h1>
      </header>
      <main className="flex-1 overflow-y-auto px-4 py-4">
        {notifications.length === 0 ? (
          <div className="mt-16 flex flex-col items-center gap-3 text-center text-muted-foreground">
            <Bell className="h-8 w-8" />
            <div className="text-sm">No notifications yet.</div>
          </div>
        ) : (
          <ul className="space-y-2">
            {notifications.map((n) => {
              const inner = (
                <div className={cn("rounded-2xl border border-border bg-card p-3", !n.isRead && "border-primary/40")}>
                  <div className="text-sm font-medium">{n.title}</div>
                  <div className="text-xs text-muted-foreground">{n.message}</div>
                </div>
              );
              return (
                <li key={n.id}>
                  {n.postId ? <Link to="/post/$id" params={{ id: n.postId }}>{inner}</Link> : inner}
                </li>
              );
            })}
          </ul>
        )}
      </main>
    </>
  );
}