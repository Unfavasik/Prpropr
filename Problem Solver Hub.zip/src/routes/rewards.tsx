import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Flame, Gift, Star } from "lucide-react";
import { toast } from "sonner";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { useStore } from "@/context/AppContext";

export const Route = createFileRoute("/rewards")({
  head: () => ({ meta: [{ title: "Rewards — ProblemApp" }, { name: "description", content: "Earn points, keep streaks, redeem rewards." }] }),
  component: RewardsPage,
});

function RewardsPage() {
  const { currentUser, checkIn } = useStore();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  if (hydrated && !currentUser) return <Navigate to="/auth" />;
  if (!currentUser) return null;

  const today = new Date().toISOString().slice(0, 10);
  const alreadyChecked = currentUser.lastCheckInDate === today;

  return (
    <>
      <AppHeader title="Rewards" />
      <main className="flex-1 overflow-y-auto px-4 py-4">
        <div className="rounded-3xl bg-gradient-to-br from-primary/30 via-primary/10 to-transparent p-5">
          <div className="flex items-center gap-4">
            <div className="grid h-16 w-16 place-items-center rounded-2xl bg-primary/25 text-primary">
              <Star className="h-8 w-8" />
            </div>
            <div>
              <div className="text-3xl font-bold">{currentUser.points}</div>
              <div className="text-xs text-muted-foreground">points earned</div>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-sm">
            <Flame className="h-4 w-4 text-orange-400" />
            <span className="font-medium">{currentUser.streak}-day streak</span>
          </div>
        </div>

        <button
          disabled={alreadyChecked}
          onClick={() => {
            const r = checkIn();
            if (r) toast.success(`+${r.awarded} points · day ${r.streak}`);
          }}
          className="mt-4 w-full rounded-2xl bg-primary py-3 font-semibold text-primary-foreground shadow-lg shadow-primary/30 disabled:opacity-50"
        >
          {alreadyChecked ? "Checked in today ✓" : "Daily check-in"}
        </button>

        <h2 className="mt-6 text-sm font-semibold text-muted-foreground">Redeem</h2>
        <div className="mt-2 space-y-2">
          {[
            { name: "Premium badge (1 week)", cost: 200 },
            { name: "Highlight your next post", cost: 100 },
            { name: "Custom avatar frame", cost: 300 },
          ].map((r) => (
            <div key={r.name} className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
                <Gift className="h-5 w-5" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{r.name}</div>
                <div className="text-xs text-muted-foreground">{r.cost} points</div>
              </div>
              <button
                disabled={currentUser.points < r.cost}
                onClick={() => toast.info("Redemption coming soon")}
                className="rounded-full border border-border px-3 py-1 text-xs disabled:opacity-40"
              >
                Redeem
              </button>
            </div>
          ))}
        </div>
      </main>
      <BottomNav />
    </>
  );
}