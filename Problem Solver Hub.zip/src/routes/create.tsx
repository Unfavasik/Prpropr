import { createFileRoute, Navigate, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { useStore } from "@/context/AppContext";
import { CATEGORIES } from "@/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/create")({
  head: () => ({ meta: [{ title: "New problem — ProblemApp" }, { name: "description", content: "Post a new problem." }] }),
  component: CreatePage,
});

function CreatePage() {
  const { currentUser, createPost } = useStore();
  const navigate = useNavigate();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<string>(CATEGORIES[0]);
  const [tags, setTags] = useState("");
  const [anonymous, setAnonymous] = useState(true);

  if (hydrated && !currentUser) return <Navigate to="/auth" />;

  return (
    <>
      <AppHeader title="New problem" />
      <main className="flex-1 overflow-y-auto px-4 py-4">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (title.trim().length < 6) return toast.error("Title too short");
            if (content.trim().length < 10) return toast.error("Add more detail");
            const p = createPost({
              title: title.trim(),
              content: content.trim(),
              category,
              tags: tags.split(",").map((t) => t.trim()).filter(Boolean).slice(0, 5),
              anonymous,
            });
            toast.success("Posted! +5 points");
            navigate({ to: "/post/$id", params: { id: p.id } });
          }}
          className="space-y-4"
        >
          <div>
            <label className="mb-1 block text-xs text-muted-foreground">Title</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What's the problem?"
              className="w-full rounded-2xl border border-border bg-card px-4 py-3 outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs text-muted-foreground">Details</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={6}
              placeholder="Add context, what you've tried, what would help..."
              className="w-full resize-none rounded-2xl border border-border bg-card px-4 py-3 outline-none focus:border-primary"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs text-muted-foreground">Category</label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCategory(c)}
                  className={cn(
                    "rounded-full border border-border px-3 py-1 text-xs text-muted-foreground",
                    category === c && "border-primary bg-primary/15 text-primary",
                  )}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs text-muted-foreground">Tags (comma separated)</label>
            <input
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="focus, study, exam"
              className="w-full rounded-2xl border border-border bg-card px-4 py-3 outline-none focus:border-primary"
            />
          </div>
          <label className="flex items-center justify-between rounded-2xl border border-border bg-card px-4 py-3">
            <div>
              <div className="text-sm font-medium">Post anonymously</div>
              <div className="text-xs text-muted-foreground">Shows your anonymous name only</div>
            </div>
            <input
              type="checkbox"
              checked={anonymous}
              onChange={(e) => setAnonymous(e.target.checked)}
              className="h-5 w-5 accent-[color:var(--color-primary)]"
            />
          </label>
          <button
            type="submit"
            className="w-full rounded-2xl bg-primary py-3 font-semibold text-primary-foreground shadow-lg shadow-primary/30"
          >
            Post problem
          </button>
        </form>
      </main>
      <BottomNav />
    </>
  );
}