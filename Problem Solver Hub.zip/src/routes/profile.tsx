import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { LogOut } from "lucide-react";
import { AppHeader } from "@/components/AppHeader";
import { BottomNav } from "@/components/BottomNav";
import { UserAvatar } from "@/components/UserAvatar";
import { PostCard } from "@/components/PostCard";
import { useStore } from "@/context/AppContext";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Profile — ProblemApp" }, { name: "description", content: "Your profile, points and posts." }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { currentUser, posts, signOut } = useStore();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  if (hydrated && !currentUser) return <Navigate to="/auth" />;
  if (!currentUser) return null;

  const mine = posts.filter((p) => p.authorId === currentUser.id);

  return (
    <>
      <AppHeader title="Profile" />
      <main className="flex-1 overflow-y-auto px-4 py-4">
        <div className="flex items-center gap-4">
          <UserAvatar seed={currentUser.avatarSeed} name={currentUser.realName} size={64} />
          <div className="min-w-0 flex-1">
            <div className="truncate text-lg font-semibold">{currentUser.realName}</div>
            <div className="text-xs text-muted-foreground">Anon: {currentUser.anonymousName}</div>
          </div>
          <button
            onClick={signOut}
            className="rounded-full border border-border p-2 text-muted-foreground hover:text-destructive"
            aria-label="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          <Stat label="Points" value={currentUser.points} />
          <Stat label="Streak" value={currentUser.streak} />
          <Stat label="Posts" value={mine.length} />
        </div>
        <h2 className="mt-6 mb-2 text-sm font-semibold text-muted-foreground">Your posts</h2>
        <div className="space-y-3">
          {mine.length === 0 && (
            <div className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
              You haven't posted yet.
            </div>
          )}
          {mine.map((p) => <PostCard key={p.id} post={p} />)}
        </div>
      </main>
      <BottomNav />
    </>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-3 text-center">
      <div className="text-lg font-bold">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}