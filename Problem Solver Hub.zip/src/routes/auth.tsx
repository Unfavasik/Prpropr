import { createFileRoute, useNavigate, Navigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import {
  Mail, Lock, User, Eye, EyeOff, ChevronLeft, ArrowRight, CheckCircle2,
  Shield, Camera, Facebook, MapPin, Grid, Phone, FileText, Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useStore } from "@/context/AppContext";
import { anonName } from "@/lib/avatar";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — ProblemApp" },
      { name: "description", content: "Sign in or create your ProblemApp account" },
    ],
  }),
  component: AuthPage,
});

type AuthStep = "login" | "signup" | "forgot" | "otp" | "profile" | "terms" | "privacy";

function AuthPage() {
  const { currentUser } = useStore();
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => setHydrated(true), []);
  if (hydrated && currentUser) return <Navigate to="/" />;

  const [step, setStep] = useState<AuthStep>("login");
  const [authTab, setAuthTab] = useState<"login" | "signup">("login");
  const [regData, setRegData] = useState({ email: "", password: "", name: "" });
  const [prefill, setPrefill] = useState({ email: "", password: "" });

  return (
    <div className="relative flex min-h-full w-full flex-1 flex-col overflow-y-auto bg-[#0B051D] pb-10 text-white">
      {/* top glow */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-0 h-[400px] overflow-hidden">
        <div className="absolute left-1/2 top-[-100px] h-[300px] w-[600px] -translate-x-1/2 rounded-[100%] border border-purple-500/20 blur-[1px]" />
        <div className="absolute left-1/2 top-0 h-[400px] w-[800px] -translate-x-1/2 rounded-[100%] border border-purple-500/10 blur-[2px]" />
        <div className="absolute left-1/2 top-[100px] h-[500px] w-[1000px] -translate-x-1/2 rounded-[100%] border border-purple-500/5 blur-[3px]" />
        <div className="absolute left-1/2 top-[-50%] h-[50%] w-full -translate-x-1/2 bg-purple-500/10 blur-[100px]" />
      </div>

      {step === "login" && (
        <div className="pointer-events-none absolute inset-x-0 bottom-0 z-0 h-[100px] overflow-hidden">
          <div className="absolute bottom-[-150px] left-1/2 h-[250px] w-[800px] -translate-x-1/2 rounded-[100%] bg-purple-900/30 blur-[20px]" />
          <div className="absolute bottom-[-200px] left-1/2 h-[300px] w-[1000px] -translate-x-1/2 rounded-[100%] border-t-2 border-purple-500/50" />
        </div>
      )}

      <div className="relative z-10 flex flex-1 flex-col">
        {(step === "login" || step === "signup" || step === "terms" || step === "privacy") && (
          <>
            <AuthTabsView
              initialTab={authTab}
              prefillEmail={prefill.email}
              prefillPassword={prefill.password}
              onForgot={() => setStep("forgot")}
              onSignup={(email, password, name) => {
                setRegData({ email, password, name });
                setStep("profile");
              }}
              onTermsClick={() => setStep("terms")}
              onPrivacyClick={() => setStep("privacy")}
            />
            {step === "terms" && <TermsView onBack={() => setStep("signup")} onAgree={() => setStep("signup")} />}
            {step === "privacy" && <PrivacyView onBack={() => setStep("signup")} onAgree={() => setStep("signup")} />}
          </>
        )}
        {step === "forgot" && <ForgotPasswordView onBack={() => setStep("login")} onNext={() => setStep("otp")} />}
        {step === "otp" && <VerifyOTPView onBack={() => setStep("forgot")} onVerify={() => setStep("login")} />}
        {step === "profile" && (
          <CompleteProfileView
            onBack={() => setStep("signup")}
            regData={regData}
            onComplete={() => {
              setPrefill({ email: regData.email, password: regData.password });
              setAuthTab("login");
              setStep("login");
            }}
          />
        )}
      </div>
    </div>
  );
}

function AuthTabsView({
  initialTab, onForgot, onSignup, onTermsClick, onPrivacyClick,
  prefillEmail = "", prefillPassword = "",
}: {
  initialTab: "login" | "signup";
  onForgot: () => void;
  onSignup: (email: string, pass: string, name: string) => void;
  onTermsClick: () => void;
  onPrivacyClick: () => void;
  prefillEmail?: string;
  prefillPassword?: string;
}) {
  const navigate = useNavigate();
  const { signIn } = useStore();
  const [tab, setTab] = useState(initialTab);
  const [showPassword, setShowPassword] = useState(false);

  const [loginEmail, setLoginEmail] = useState(prefillEmail);
  const [loginPassword, setLoginPassword] = useState(prefillPassword);
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState("");

  const [signupName, setSignupName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");
  const [signupConfirmPassword, setSignupConfirmPassword] = useState("");
  const [signupError, setSignupError] = useState("");

  useEffect(() => { setLoginEmail(prefillEmail); setLoginPassword(prefillPassword); }, [prefillEmail, prefillPassword]);

  const handleLoginSubmit = (e: FormEvent) => {
    e.preventDefault();
    setLoginError("");
    if (!loginEmail || !loginPassword) return setLoginError("Please enter email and password");
    setLoginLoading(true);
    // Demo auth: derive display name from email local-part
    const name = loginEmail.split("@")[0] || "User";
    setTimeout(() => {
      signIn(name);
      toast.success("Welcome back!");
      navigate({ to: "/", replace: true });
    }, 300);
  };

  const handleGoogleLogin = () => {
    setLoginError("");
    setLoginLoading(true);
    setTimeout(() => {
      signIn("Google User");
      toast.success("Signed in with Google");
      navigate({ to: "/", replace: true });
    }, 300);
  };

  const handleSignupSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSignupError("");
    if (!signupName || !signupEmail || !signupPassword || !signupConfirmPassword) return setSignupError("Please fill in all fields");
    if (signupPassword !== signupConfirmPassword) return setSignupError("Passwords do not match");
    if (signupPassword.length < 6) return setSignupError("Password must be at least 6 characters");
    onSignup(signupEmail, signupPassword, signupName);
  };

  return (
    <div className="flex flex-1 flex-col px-6 pt-8">
      <div className="mb-10 flex flex-col items-center">
        <div className="relative mb-3 flex h-20 w-20 items-center justify-center">
          <div className="absolute inset-0 rounded-full bg-purple-500/20 blur-[20px]" />
          <div className="relative z-10 grid h-16 w-16 place-items-center overflow-hidden rounded-[16px] border border-white/5 bg-gradient-to-br from-purple-600 to-indigo-600 shadow-xl">
            <Sparkles className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-[22px] font-black tracking-tight">
          <span className="text-white">Problem</span>
          <span className="text-purple-400">App</span>
        </h1>
        <p className="text-[13px] text-gray-400">Share. Get Help. Solve Together.</p>
      </div>

      <div className="mx-auto mb-8 flex w-full max-w-[300px] border-b border-white/10">
        <button
          className={cn("flex-1 border-b-2 py-3 text-[15px] font-bold transition-colors", tab === "login" ? "border-purple-500 text-white" : "border-transparent text-gray-500 hover:text-gray-300")}
          onClick={() => setTab("login")}
        >Login</button>
        <button
          className={cn("flex-1 border-b-2 py-3 text-[15px] font-bold transition-colors", tab === "signup" ? "border-purple-500 text-white" : "border-transparent text-gray-500 hover:text-gray-300")}
          onClick={() => setTab("signup")}
        >Sign Up</button>
      </div>

      {tab === "login" ? (
        <form className="flex flex-1 flex-col" onSubmit={handleLoginSubmit}>
          <div className="mb-4 space-y-4">
            {loginError && <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-400">{loginError}</div>}
            <div className="relative">
              <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
              <input type="text" placeholder="Email Address" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-4 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
            </div>
            <div className="relative">
              <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
              <input type={showPassword ? "text" : "password"} placeholder="Password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-12 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 transition-colors hover:text-white">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <div className="mb-8 flex justify-end">
            <button type="button" onClick={onForgot} className="text-[13px] font-medium text-purple-400 transition-colors hover:text-purple-300">Forgot Password?</button>
          </div>

          <button disabled={loginLoading} type="submit" className="mb-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-4 font-bold text-white shadow-lg shadow-purple-900/50 transition-all hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50">
            {loginLoading ? "Logging in..." : "Login"} <ArrowRight size={18} />
          </button>

          <div className="mb-8 flex items-center gap-4">
            <div className="h-px flex-1 bg-white/5" />
            <span className="text-[12px] font-medium text-gray-500">or continue with</span>
            <div className="h-px flex-1 bg-white/5" />
          </div>

          <div className="mb-8 flex justify-center gap-4">
            <button type="button" onClick={handleGoogleLogin} className="flex h-[60px] w-[80px] flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/5 bg-[#120B29] transition-colors hover:bg-[#1A1230]">
              <svg viewBox="0 0 24 24" width="20" height="20"><g transform="matrix(1,0,0,1,27.009001,-39.238998)"><path fill="#4285F4" d="M -3.264 51.509 C -3.264 50.719 -3.334 49.969 -3.454 49.239 L -14.754 49.239 L -14.754 53.749 L -8.284 53.749 C -8.574 55.229 -9.424 56.479 -10.684 57.329 L -10.684 60.329 L -6.824 60.329 C -4.564 58.239 -3.264 55.159 -3.264 51.509 Z"/><path fill="#34A853" d="M -14.754 63.239 C -11.514 63.239 -8.804 62.159 -6.824 60.329 L -10.684 57.329 C -11.764 58.049 -13.134 58.489 -14.754 58.489 C -17.884 58.489 -20.534 56.379 -21.484 53.529 L -25.464 53.529 L -25.464 56.619 C -23.494 60.539 -19.444 63.239 -14.754 63.239 Z"/><path fill="#FBBC05" d="M -21.484 53.529 C -21.734 52.809 -21.864 52.039 -21.864 51.239 C -21.864 50.439 -21.724 49.669 -21.484 48.949 L -21.484 45.859 L -25.464 45.859 C -26.284 47.479 -26.754 49.299 -26.754 51.239 C -26.754 53.179 -26.284 54.999 -25.464 56.619 L -21.484 53.529 Z"/><path fill="#EA4335" d="M -14.754 43.989 C -12.984 43.989 -11.404 44.599 -10.154 45.789 L -6.734 42.369 C -8.804 40.429 -11.514 39.239 -14.754 39.239 C -19.444 39.239 -23.494 41.939 -25.464 45.859 L -21.484 48.949 C -20.534 46.099 -17.884 43.989 -14.754 43.989 Z"/></g></svg>
              <span className="text-[10px] font-medium text-gray-400">Google</span>
            </button>
            <button type="button" className="flex h-[60px] w-[80px] flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/5 bg-[#120B29] transition-colors hover:bg-[#1A1230]">
              <Facebook size={20} className="fill-current text-[#1877F2]" />
              <span className="text-[10px] font-medium text-gray-400">Facebook</span>
            </button>
            <button type="button" className="flex h-[60px] w-[80px] flex-col items-center justify-center gap-1.5 rounded-2xl border border-white/5 bg-[#120B29] transition-colors hover:bg-[#1A1230]">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.05 20.28c-.98.95-2.05.94-3.08.51-1.09-.44-2.09-.46-3.24 0-1.44.62-2.2.44-3.06-.51C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/></svg>
              <span className="text-[10px] font-medium text-gray-400">Apple</span>
            </button>
          </div>

          <div className="mt-auto text-center">
            <span className="text-[13px] text-gray-400">Don't have an account? </span>
            <button type="button" onClick={() => setTab("signup")} className="text-[13px] font-bold text-purple-400 hover:underline">Sign Up</button>
          </div>
        </form>
      ) : (
        <form className="flex flex-1 flex-col" onSubmit={handleSignupSubmit}>
          <div className="mb-6 space-y-4">
            {signupError && <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-400">{signupError}</div>}
            <div className="relative">
              <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
              <input type="text" placeholder="Full Name" value={signupName} onChange={(e) => setSignupName(e.target.value)} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-4 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
            </div>
            <div className="relative">
              <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
              <input type="email" placeholder="Email Address" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-4 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
            </div>
            <div className="relative">
              <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
              <input type={showPassword ? "text" : "password"} placeholder="Password" value={signupPassword} onChange={(e) => setSignupPassword(e.target.value)} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-12 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <div className="relative">
              <Lock size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
              <input type={showPassword ? "text" : "password"} placeholder="Confirm Password" value={signupConfirmPassword} onChange={(e) => setSignupConfirmPassword(e.target.value)} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-12 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
              <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <label className="group mb-6 flex cursor-pointer items-start gap-3">
            <div className="relative mt-0.5 flex shrink-0 items-center justify-center">
              <input type="checkbox" defaultChecked className="peer h-5 w-5 cursor-pointer appearance-none rounded border-2 border-purple-500/50 bg-[#120B29] transition-colors checked:border-purple-600 checked:bg-purple-600" />
              <CheckCircle2 size={14} className="pointer-events-none absolute text-white opacity-0 transition-opacity peer-checked:opacity-100" />
            </div>
            <span className="text-[12px] leading-snug text-gray-400">
              I agree to the <button type="button" onClick={onTermsClick} className="text-purple-400 hover:underline">Terms of Service</button> and <button type="button" onClick={onPrivacyClick} className="text-purple-400 hover:underline">Privacy Policy</button>
            </span>
          </label>

          <button type="submit" className="mb-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-4 font-bold text-white shadow-lg shadow-purple-900/50 transition-all hover:from-purple-500 hover:to-indigo-500">
            Next <ArrowRight size={18} />
          </button>

          <div className="mt-auto text-center">
            <span className="text-[13px] text-gray-400">Already have an account? </span>
            <button type="button" onClick={() => setTab("login")} className="text-[13px] font-bold text-purple-400 hover:underline">Login</button>
          </div>
        </form>
      )}
    </div>
  );
}

function ForgotPasswordView({ onBack, onNext }: { onBack: () => void; onNext: () => void }) {
  const [method, setMethod] = useState<"email" | "phone">("email");
  return (
    <div className="flex flex-1 flex-col px-6 pt-12">
      <button onClick={onBack} className="-ml-2 mb-6 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/5">
        <ChevronLeft size={28} />
      </button>
      <h2 className="mb-2 text-[28px] font-bold leading-tight text-white">Forgot<br /><span className="text-purple-400">Password?</span></h2>
      <p className="mb-8 max-w-[280px] text-[13px] leading-relaxed text-gray-400">
        No worries! Enter your registered email or phone and we'll send you a link to reset your password.
      </p>
      <div className="mb-8 flex rounded-2xl border border-white/5 bg-[#120B29] p-1">
        <button onClick={() => setMethod("email")} className={cn("flex-1 rounded-xl py-3 text-[14px] font-bold transition-all", method === "email" ? "bg-purple-600 text-white shadow-lg shadow-purple-900/30" : "text-gray-500 hover:text-gray-300")}>Email</button>
        <button onClick={() => setMethod("phone")} className={cn("flex-1 rounded-xl py-3 text-[14px] font-bold transition-all", method === "phone" ? "bg-purple-600 text-white shadow-lg shadow-purple-900/30" : "text-gray-500 hover:text-gray-300")}>Phone</button>
      </div>
      <div className="relative mb-8">
        {method === "email" ? <Mail size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" /> : <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />}
        <input type={method === "email" ? "email" : "tel"} placeholder={method === "email" ? "Enter your email" : "Enter your phone number"} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-4 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
      </div>
      <button onClick={onNext} className="mb-8 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-4 font-bold text-white shadow-lg shadow-purple-900/50 transition-all hover:from-purple-500 hover:to-indigo-500">
        Send Reset Link <ArrowRight size={18} />
      </button>
      <div className="relative mb-8 mt-auto flex items-center gap-4 overflow-hidden rounded-2xl border border-white/5 bg-[#120B29] p-4">
        <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-purple-900/20 to-transparent" />
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-purple-500/20 bg-purple-500/10 text-purple-400"><Shield size={20} /></div>
        <p className="text-[12px] leading-snug text-gray-400">We will send a password reset link to your {method}.</p>
      </div>
    </div>
  );
}

function VerifyOTPView({ onBack, onVerify }: { onBack: () => void; onVerify: () => void }) {
  return (
    <div className="flex flex-1 flex-col items-center px-6 pt-12 text-center">
      <div className="mb-6 flex w-full justify-start">
        <button onClick={onBack} className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/5">
          <ChevronLeft size={28} />
        </button>
      </div>
      <div className="relative mb-8 h-[150px] w-[180px]">
        <div className="absolute inset-0 flex items-center justify-center">
          <svg width="140" height="120" viewBox="0 0 140 120" fill="none">
            <path d="M10 30L70 70L130 30V100C130 105.523 125.523 110 120 110H20C14.4772 110 10 105.523 10 100V30Z" fill="#7C3AED" />
            <path d="M130 30L70 70L10 30C10 24.4772 14.4772 20 20 20H120C125.523 20 130 24.4772 130 30Z" fill="#6D28D9" />
          </svg>
        </div>
        <div className="absolute left-1/2 top-4 flex h-[50px] w-[100px] -translate-x-1/2 -rotate-2 items-center justify-center rounded-lg bg-white shadow-md">
          <span className="text-[20px] font-black tracking-[4px] text-purple-600">123456</span>
        </div>
        <div className="absolute bottom-2 right-4 z-10 grid h-8 w-8 place-items-center rounded-full border-[3px] border-[#0B051D] bg-green-500">
          <CheckCircle2 size={16} className="text-white" />
        </div>
      </div>
      <h2 className="mb-2 text-[28px] font-bold text-white">Verify <span className="text-purple-400">OTP</span></h2>
      <p className="mb-8 max-w-[240px] text-[13px] text-gray-400">Enter the 6-digit code we just sent you.</p>
      <div className="mb-8 flex w-full max-w-[320px] justify-center gap-2">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <input key={i} type="text" maxLength={1} className="h-14 w-12 rounded-xl border border-white/5 bg-[#120B29] text-center text-[20px] font-bold text-white transition-colors focus:border-purple-500 focus:bg-purple-900/10 focus:outline-none" />
        ))}
      </div>
      <div className="mb-8 text-[13px] text-gray-400">Resend code in <span className="font-bold text-white">00:45</span></div>
      <button onClick={onVerify} className="mt-auto flex w-full max-w-[320px] items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-4 font-bold text-white shadow-lg shadow-purple-900/50 transition-all hover:from-purple-500 hover:to-indigo-500">
        Verify & Continue <ArrowRight size={18} />
      </button>
    </div>
  );
}

function CompleteProfileView({
  onBack, onComplete, regData,
}: {
  onBack: () => void;
  onComplete: () => void;
  regData: { email: string; password: string; name: string };
}) {
  const { signUp } = useStore();
  const navigate = useNavigate();
  const [username, setUsername] = useState(anonName());
  const [location, setLocation] = useState("");
  const [interest, setInterest] = useState("");
  const [isDetectingLocation, setIsDetectingLocation] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleDetectLocation = () => {
    setIsDetectingLocation(true);
    if (!navigator.geolocation) {
      setLocation("Global");
      setIsDetectingLocation(false);
      return;
    }
    const timeoutId = setTimeout(() => { setLocation("Global"); setIsDetectingLocation(false); }, 5000);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        clearTimeout(timeoutId);
        try {
          const { latitude, longitude } = position.coords;
          const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
          const data = await res.json();
          const a = data.address || {};
          const parts = [a.city || a.town || a.village, a.state, a.country].filter(Boolean);
          setLocation([...new Set(parts)].join(", ") || "Unknown Location");
          toast.success("Location detected");
        } catch { setLocation("Global"); }
        finally { setIsDetectingLocation(false); }
      },
      () => { clearTimeout(timeoutId); setLocation("Global"); setIsDetectingLocation(false); },
      { enableHighAccuracy: true, timeout: 5000, maximumAge: 0 },
    );
  };

  const handleCompleteProfile = (e: FormEvent) => {
    e.preventDefault();
    setError("");
    if (!username || !location || !interest) return setError("Please fill in all fields");
    setLoading(true);
    setTimeout(() => {
      signUp({ realName: regData.name, anonymousName: username, location, interest });
      toast.success("Account created!");
      onComplete();
      navigate({ to: "/", replace: true });
    }, 300);
  };

  return (
    <div className="flex flex-1 flex-col px-6 pt-12">
      <button onClick={onBack} className="-ml-2 mb-4 flex h-10 w-10 items-center justify-center rounded-full text-white transition-colors hover:bg-white/5">
        <ChevronLeft size={28} />
      </button>
      <div className="mb-8 flex justify-center">
        <div className="relative">
          <div className="grid h-24 w-24 place-items-center overflow-hidden rounded-full border-2 border-purple-500 bg-[#120B29]">
            <User size={40} className="text-purple-500/50" />
          </div>
          <button type="button" className="absolute bottom-0 right-0 grid h-8 w-8 place-items-center rounded-full border-2 border-[#0B051D] bg-purple-600 shadow-lg transition-colors hover:bg-purple-500">
            <Camera size={14} className="text-white" />
          </button>
        </div>
      </div>
      <h2 className="mb-2 text-center text-[28px] font-bold text-white">Complete Your <span className="text-purple-400">Profile</span></h2>
      <p className="mb-8 text-center text-[13px] text-gray-400">Help others know you better.</p>

      <form className="flex flex-1 flex-col" onSubmit={handleCompleteProfile}>
        <div className="mb-8 space-y-4">
          {error && <div className="rounded-lg border border-red-500/20 bg-red-500/10 p-3 text-sm text-red-400">{error}</div>}
          <div className="relative">
            <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
            <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-20 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
            <button type="button" onClick={() => setUsername(anonName())} className="absolute right-4 top-1/2 -translate-y-1/2 text-[12px] font-bold text-purple-400 hover:text-purple-300">Random</button>
          </div>
          <div className="relative">
            <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
            <input type="text" placeholder="Select Your Location" value={location} onChange={(e) => setLocation(e.target.value)} onClick={!location ? handleDetectLocation : undefined} readOnly={isDetectingLocation} className="w-full rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-24 text-[14px] text-white placeholder:text-gray-600 focus:border-purple-500/50 focus:outline-none" />
            <button type="button" onClick={handleDetectLocation} disabled={isDetectingLocation} className="absolute right-4 top-1/2 -translate-y-1/2 text-[12px] font-bold text-purple-400 hover:text-purple-300 disabled:opacity-50">
              {isDetectingLocation ? "Detecting..." : "Detect"}
            </button>
          </div>
          <div className="relative">
            <Grid size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500" />
            <select value={interest} onChange={(e) => setInterest(e.target.value)} className="w-full appearance-none rounded-2xl border border-white/5 bg-[#120B29] py-4 pl-12 pr-4 text-[14px] text-gray-400 focus:border-purple-500/50 focus:outline-none">
              <option value="" disabled>Select Your Interest</option>
              <option value="tech">Technology & Coding</option>
              <option value="science">Science & Math</option>
              <option value="career">Career Advice</option>
              <option value="health">Health & Fitness</option>
              <option value="relationships">Relationships</option>
            </select>
            <div className="pointer-events-none absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9" /></svg>
            </div>
          </div>
        </div>

        <div className="mb-8 mt-auto">
          <button disabled={loading} type="submit" className="mb-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-4 font-bold text-white shadow-lg shadow-purple-900/50 transition-all hover:from-purple-500 hover:to-indigo-500 disabled:opacity-50">
            {loading ? "Creating Account..." : "Create Account"} <ArrowRight size={18} />
          </button>
          <p className="text-center text-[12px] text-gray-500">You can change this later in settings</p>
        </div>
      </form>
    </div>
  );
}

function TermsView({ onBack, onAgree }: { onBack: () => void; onAgree: () => void }) {
  const terms = [
    { title: "Acceptance of Terms", text: "By accessing or using Problem App, you agree to be bound by these Terms of Service." },
    { title: "Use of the App", text: "You agree to use the app only for lawful purposes and in a way that does not infringe the rights of others." },
    { title: "User Accounts", text: "You are responsible for maintaining the confidentiality of your account and for all activities under it." },
    { title: "User Content", text: "You retain ownership of the content you post, but you grant us a license to display it within the app." },
    { title: "Prohibited Conduct", text: "You agree not to post harmful, abusive, or illegal content or engage in activity that disrupts the app." },
    { title: "Termination", text: "We may suspend or terminate your access to the app at any time for violating these terms." },
    { title: "Changes to Terms", text: "We may update these terms from time to time. We'll notify you of significant changes." },
  ];
  return <LegalOverlay title="Terms of Service" heading={<>Terms <span className="text-purple-400">of Service</span></>} icon={<FileText size={32} className="fill-purple-400/20 text-purple-300" />} items={terms} onBack={onBack} onAgree={onAgree} />;
}

function PrivacyView({ onBack, onAgree }: { onBack: () => void; onAgree: () => void }) {
  const policies = [
    { title: "Information We Collect", text: "We collect information you provide directly, such as your name, email, and profile details." },
    { title: "How We Use Information", text: "We use your information to provide and improve our services, communicate with you, and ensure app safety." },
    { title: "Information Sharing", text: "We do not sell your personal information. We may share with trusted providers who help us operate the app." },
    { title: "Data Security", text: "We implement industry-standard security measures to protect your data from unauthorized access." },
    { title: "Your Rights", text: "You can access, update, or delete your information anytime from your account settings." },
    { title: "Cookies", text: "We use cookies to enhance your experience and analyze app performance." },
    { title: "Changes to This Policy", text: "We may update this policy from time to time. We'll notify you of any significant changes." },
  ];
  return <LegalOverlay title="Privacy Policy" heading={<>Privacy <span className="text-purple-400">Policy</span></>} icon={<Lock size={32} className="fill-purple-400/20 text-purple-300" />} items={policies} onBack={onBack} onAgree={onAgree} />;
}

function LegalOverlay({
  title, heading, icon, items, onBack, onAgree,
}: {
  title: string;
  heading: React.ReactNode;
  icon: React.ReactNode;
  items: { title: string; text: string }[];
  onBack: () => void;
  onAgree: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex flex-col overflow-y-auto bg-[#0B051D]">
      <div className="sticky top-0 z-10 flex items-center bg-[#0B051D]/90 p-4 backdrop-blur-md">
        <button onClick={onBack} className="rounded-full p-2 text-white transition-colors hover:bg-white/10">
          <ChevronLeft size={24} />
        </button>
        <h1 className="mr-10 flex-1 text-center text-lg font-bold text-white">{title}</h1>
      </div>
      <div className="flex flex-col items-center px-5 pb-8">
        <div className="relative mb-6 flex h-24 w-24 items-center justify-center">
          <div className="absolute inset-0 animate-pulse rounded-full bg-purple-500/20 blur-xl" />
          <div className="absolute h-[40%] w-[120%] rotate-[-15deg] rounded-full border border-purple-500/30" />
          <div className="absolute h-[120%] w-[40%] rotate-45 rounded-full border border-purple-500/20" />
          <div className="relative z-10 drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]">
            <Shield size={80} className="fill-[#1A1040] text-purple-600" strokeWidth={1.5} />
            <div className="absolute inset-0 flex items-center justify-center">{icon}</div>
          </div>
        </div>
        <h2 className="mb-2 text-3xl font-bold text-white">{heading}</h2>
        <p className="mb-8 text-sm text-gray-400">Last updated: May 20, 2025</p>
        <div className="w-full rounded-3xl border border-white/5 bg-[#120B29] p-5">
          <div className="space-y-6">
            {items.map((it, i) => (
              <div key={i} className="flex gap-4">
                <div className="mt-1 grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-purple-500/20 font-bold text-purple-400">{i + 1}</div>
                <div>
                  <h3 className="mb-1 font-bold text-white">{it.title}</h3>
                  <p className="text-[13px] leading-relaxed text-gray-400">{it.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="sticky bottom-0 z-10 mt-auto border-t border-white/5 bg-[#0B051D] p-4">
        <button onClick={onAgree} className="w-full rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 py-4 font-bold text-white shadow-lg shadow-purple-900/50 transition-all hover:from-purple-500 hover:to-indigo-500">
          I Agree
        </button>
      </div>
    </div>
  );
}