import type { ReactNode } from "react";

export function PhoneFrame({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen w-full bg-black flex items-stretch justify-center">
      <div className="relative flex w-full max-w-[500px] flex-col bg-background text-foreground sm:my-4 sm:min-h-[calc(100vh-2rem)] sm:rounded-3xl sm:border sm:border-border sm:shadow-2xl sm:shadow-primary/10 sm:overflow-hidden">
        {children}
      </div>
    </div>
  );
}