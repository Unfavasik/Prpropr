import { Link } from "@tanstack/react-router";
import { ArrowBigUp, CheckCircle2, MessageCircle } from "lucide-react";
import { UserAvatar } from "./UserAvatar";
import { useStore } from "@/context/AppContext";
import type { Post } from "@/types";
import { cn } from "@/lib/utils";

function timeAgo(iso: string) {
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return s + "s";
  if (s < 3600) return Math.floor(s / 60) + "m";
  if (s < 86400) return Math.floor(s / 3600) + "h";
  return Math.floor(s / 86400) + "d";
}

export function PostCard({ post }: { post: Post }) {
  const { currentUser, replies, toggleUpvote } = useStore();
  const replyCount = replies.filter((r) => r.postId === post.id).length;
  const upvoted = currentUser ? post.upvotedBy.includes(currentUser.id) : false;
  return (
    <article className="rounded-2xl border border-border bg-card p-4">
      <div className="flex items-center gap-2.5">
        <UserAvatar seed={post.authorAvatarSeed} name={post.authorName} size={36} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 text-sm">
            <span className="truncate font-medium">{post.authorName}</span>
            {post.anonymous && <span className="rounded-full bg-secondary px-1.5 py-0.5 text-[10px] text-muted-foreground">anon</span>}
          </div>
          <div className="text-xs text-muted-foreground">{post.category} · {timeAgo(post.createdAt)} ago</div>
        </div>
        {post.hasAcceptedSolution && <CheckCircle2 className="h-5 w-5 shrink-0 text-[color:var(--success)]" />}
      </div>
      <Link to="/post/$id" params={{ id: post.id }} className="mt-3 block">
        <h3 className="text-base font-semibold leading-snug">{post.title}</h3>
        <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{post.content}</p>
      </Link>
      {post.tags.length > 0 && (
        <div className="mt-3 flex flex-wrap gap-1.5">
          {post.tags.map((t) => (
            <span key={t} className="rounded-full bg-secondary px-2 py-0.5 text-[11px] text-muted-foreground">#{t}</span>
          ))}
        </div>
      )}
      <div className="mt-3 flex items-center gap-4 text-sm">
        <button
          onClick={() => toggleUpvote(post.id)}
          className={cn(
            "flex items-center gap-1 rounded-full px-2 py-1 text-muted-foreground transition-colors hover:text-primary",
            upvoted && "bg-primary/15 text-primary",
          )}
        >
          <ArrowBigUp className="h-4 w-4" />
          <span className="tabular-nums">{post.upvotes}</span>
        </button>
        <Link to="/post/$id" params={{ id: post.id }} className="flex items-center gap-1 text-muted-foreground">
          <MessageCircle className="h-4 w-4" />
          <span className="tabular-nums">{replyCount}</span>
        </Link>
      </div>
    </article>
  );
}