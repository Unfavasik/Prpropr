import { Link } from "@tanstack/react-router";
import { Bell, Sparkles } from "lucide-react";
import { useStore } from "@/context/AppContext";

export function AppHeader({ title }: { title: string }) {
  const { notifications } = useStore();
  const unread = notifications.filter((n) => !n.isRead).length;
  return (
    <header className="sticky top-0 z-20 flex items-center justify-between gap-3 border-b border-border bg-background/80 px-4 py-3 backdrop-blur">
      <div className="flex min-w-0 items-center gap-2">
        <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-primary/20 text-primary">
          <Sparkles className="h-4 w-4" />
        </div>
        <h1 className="truncate text-lg font-semibold">{title}</h1>
      </div>
      <Link to="/notifications" className="relative rounded-full p-2 text-muted-foreground hover:bg-secondary hover:text-foreground">
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute right-1 top-1 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[10px] font-semibold text-primary-foreground">
            {unread}
          </span>
        )}
      </Link>
    </header>
  );
}