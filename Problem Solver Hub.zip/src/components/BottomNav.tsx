import { Link } from "@tanstack/react-router";
import { Home, MessagesSquare, PlusCircle, Gift, User } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { to: "/", label: "Home", icon: Home, exact: true, primary: false },
  { to: "/adda", label: "Adda", icon: MessagesSquare, exact: false, primary: false },
  { to: "/create", label: "Create", icon: PlusCircle, exact: false, primary: true },
  { to: "/rewards", label: "Rewards", icon: Gift, exact: false, primary: false },
  { to: "/profile", label: "Profile", icon: User, exact: false, primary: false },
] as const;

export function BottomNav() {
  return (
    <nav className="sticky bottom-0 z-30 border-t border-border bg-card/90 backdrop-blur">
      <ul className="grid grid-cols-5">
        {items.map((it) => {
          const Icon = it.icon;
          return (
            <li key={it.to} className="flex">
              <Link
                to={it.to}
                activeOptions={{ exact: it.exact }}
                className="flex flex-1 flex-col items-center justify-center gap-1 py-2.5 text-xs text-muted-foreground data-[status=active]:text-primary"
              >
                <Icon className={cn("h-5 w-5", it.primary && "h-7 w-7 text-primary")} />
                <span>{it.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}