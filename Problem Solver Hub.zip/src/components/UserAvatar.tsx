import { avatarGradient } from "@/lib/avatar";
import { cn } from "@/lib/utils";

export function UserAvatar({ seed, name, size = 40, className }: { seed: string; name: string; size?: number; className?: string }) {
  const initial = (name || "?").trim().charAt(0).toUpperCase();
  return (
    <div
      className={cn("shrink-0 grid place-items-center rounded-full text-white font-semibold select-none", className)}
      style={{ width: size, height: size, background: avatarGradient(seed), fontSize: size * 0.42 }}
      aria-hidden
    >
      {initial}
    </div>
  );
}